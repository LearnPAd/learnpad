/***** BuechiFromLTL : BuechiFromLTL.h *****/

/* Written by Denis Oddoux, LIAFA, France                                 */
/* Copyright (c) 2001  Denis Oddoux                                       */
/* Modified by Paul Gastin, LSV, France                                   */
/* Copyright (c) 2007  Paul Gastin                                        */
/*                                                                        */
/* This program is free software; you can redistribute it and/or modify   */
/* it under the terms of the GNU General Public License as published by   */
/* the Free Software Foundation; either version 2 of the License, or      */
/* (at your option) any later version.                                    */
/*                                                                        */
/* This program is distributed in the hope that it will be useful,        */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of         */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          */
/* GNU General Public License for more details.                           */
/*                                                                        */
/* You should have received a copy of the GNU General Public License      */
/* along with this program; if not, write to the Free Software            */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA*/
/*                                                                        */
/* Based on the translation algorithm by Gastin and Oddoux,               */
/* presented at the 13th International Conference on Computer Aided       */
/* Verification, CAV 2001, Paris, France.                                 */
/* Proceedings - LNCS 2102, pp. 53-65                                     */
/*                                                                        */
/* Send bug-reports and/or questions to Paul Gastin                       */
/* http://www.lsv.ens-cachan.fr/~gastin                                   */
/*                                                                        */
/* Some of the code in this file was taken from the Spin software         */
/* Written by Gerard J. Holzmann, Bell Laboratories, U.S.A.               */


#pragma once

typedef struct tl_Symbol
{
    char        *name;
    struct tl_Symbol    *next;  /* linked list, symbol table */
} tl_Symbol;

typedef struct tl_Node
{
    short       ntyp;   /* node type */
    struct tl_Symbol    *sym;
    struct tl_Node  *lft;   /* tree */
    struct tl_Node  *rgt;   /* tree */
    struct tl_Node  *nxt;   /* if linked list */
} tl_Node;

typedef struct Graph
{
    tl_Symbol       *name;
    tl_Symbol       *incoming;
    tl_Symbol       *outgoing;
    tl_Symbol       *oldstring;
    tl_Symbol       *nxtstring;
    tl_Node     *New;
    tl_Node     *Old;
    tl_Node     *Other;
    tl_Node     *Next;
    unsigned char   isred[64], isgrn[64];
    unsigned char   redcnt, grncnt;
    unsigned char   reachable;
    struct Graph    *nxt;
} Graph;

typedef struct Mapping
{
    char    *from;
    Graph   *to;
    struct Mapping  *nxt;
} Mapping;

typedef struct ATrans
{
    int *to;
    int *pos;
    int *neg;
    struct ATrans *nxt;
} ATrans;

typedef struct AProd
{
    int astate;
    struct ATrans *prod;
    struct ATrans *trans;
    struct AProd *nxt;
    struct AProd *prv;
} AProd;


typedef struct GTrans
{
    int *pos;
    int *neg;
    struct GState *to;
    int *final;
    struct GTrans *nxt;
} GTrans;

typedef struct GState
{
    int id;
    int incoming;
    int *nodes_set;
    struct GTrans *trans;
    struct GState *nxt;
    struct GState *prv;
} GState;

typedef struct BTrans
{
    struct BState *to;
    int *pos;
    int *neg;
    struct BTrans *nxt;
} BTrans;

typedef struct BState
{
    struct GState *gstate;
    int id;
    int incoming;
    int final;
    struct BTrans *trans;
    struct BState *nxt;
    struct BState *prv;
} BState;

typedef struct GScc
{
    struct GState *gstate;
    int rank;
    int theta;
    struct GScc *nxt;
} GScc;

typedef struct BScc
{
    struct BState *bstate;
    int rank;
    int theta;
    struct BScc *nxt;
} BScc;

enum
{
    ALWAYS = 257,
    AND,        /* 258 */
    EQUIV,      /* 259 */
    EVENTUALLY, /* 260 */
    FALSE,      /* 261 */
    IMPLIES,    /* 262 */
    NOT,        /* 263 */
    OR,     /* 264 */
    PREDICATE,  /* 265 */
    TRUE,       /* 266 */
    U_OPER,     /* 267 */
    V_OPER      /* 268 */
    , NEXT      /* 269 */
};

#ifdef __cplusplus
extern "C" {
#endif


tl_Node *tl_nn(int, tl_Node *, tl_Node *);
tl_Symbol   *tl_lookup(char *);
void    trans(tl_Node *);
tl_Node *bin_simpler(tl_Node *ptr);

extern BState *bstates;
extern int accepting_state;
extern char **sym_table;
extern int sym_size;

tl_Node *push_negation(tl_Node *n);

#ifdef __cplusplus
}
#endif
